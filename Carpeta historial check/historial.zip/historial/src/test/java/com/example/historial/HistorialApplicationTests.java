package com.example.historial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HistorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
