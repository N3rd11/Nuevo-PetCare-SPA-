package com.example.categoria.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.categoria.model.categoria;
import com.example.categoria.service.categoriaService;

@RestController
@RequestMapping("/api/v1/categorias")
public class categoriaController {

    @Autowired
    private categoriaService CategoriaService;

    // Obtener todas las categorías
    @GetMapping
    public ResponseEntity<List<categoria>> obtenerCategorias() {
        List<categoria> categorias = CategoriaService.getCategorias();
        if (categorias.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(categorias);
    }

    // Obtener una categoría por ID
    @GetMapping("/{id}")
    public ResponseEntity<categoria> obtenerCategoria(@PathVariable Long id) {
        try {
            categoria categoria = CategoriaService.getCategoria(id);
            return ResponseEntity.ok(categoria);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    // Crear una nueva categoría
    @PostMapping
    public ResponseEntity<categoria> guardarCategoria(@RequestBody categoria nueva) {
        return ResponseEntity.status(201).body(CategoriaService.saveCategoria(nueva));
    }

    // Actualizar una categoría
    @PutMapping("/{id}")
    public ResponseEntity<categoria> actualizarCategoria(@PathVariable Long id, @RequestBody categoria actualizada) {
        try {
            categoria actualizadaCategoria = CategoriaService.updateCategoria(id, actualizada);
            return ResponseEntity.ok(actualizadaCategoria);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    // Eliminar una categoría
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarCategoria(@PathVariable Long id) {
        try {
            CategoriaService.deleteCategoria(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}
    


