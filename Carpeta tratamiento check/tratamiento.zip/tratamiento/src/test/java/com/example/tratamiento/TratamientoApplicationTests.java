package com.example.tratamiento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TratamientoApplicationTests {

	@Test
	void contextLoads() {
	}

}
