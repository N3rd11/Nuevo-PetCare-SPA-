package com.example.tratamiento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TratamientoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TratamientoApplication.class, args);
	}

}
